The structure of the files:
VARIABLE_SCENARIO_PERIOD

### Variables ###
bio01 = Annual Mean Temperature
bio12 = Annual Mean Precipitation

### Scenarios ###
126 = SSP1 - 2.6
585 = SSP5 - 8.5

### Periods ###
8110 = 1981-2010*
1140 = 2011-2040
4170 = 2041-2070
7100 = 2071-2100

*There are no scenarios for this period.